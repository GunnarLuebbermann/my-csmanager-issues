chrome.commands.onCommand.addListener((command) => {
  console.log("Receive ShortCut");
    var greeting = "";
    if(command === "toggle-feature-aufnahme-starten"){
      greeting = "AufnahmeStarten";
    }
    else if(command === "toggle-feature-aufnahme-beenden"){
      greeting = "AufnahmeBeenden";
    }
    else if(command === "toggle-feature-aufnahme-ok"){
      greeting = "AufnahmeOK";
    }
    else if(command === "toggle-feature-aufnahme-nichtok"){
      greeting = "AufnahmeNichtOK";
    }
    (async () => {
      const [tab] = await chrome.tabs.query({active: true, lastFocusedWindow: true});
      const response = await chrome.tabs.sendMessage(tab.id, {greeting: greeting});
    })();

  });


  

