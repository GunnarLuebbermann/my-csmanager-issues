chrome.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {
      window.postMessage(
        {type : "FROM_CSMANAGE_EXT", text : request.greeting}, "*");  
           
    }
  );
